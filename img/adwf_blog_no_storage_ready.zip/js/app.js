const firebaseConfig = {
  apiKey: "AIzaSyAT2j_hi9UPYE9Z9VLu5Ro0DZvPeHEaloc",
  authDomain: "adwf-blog.firebaseapp.com",
  projectId: "adwf-blog",
  storageBucket: "adwf-blog.firebasestorage.app",
  messagingSenderId: "24598016113",
  appId: "1:24598016113:web:946379a7a589426e4f6bd0"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

if(document.getElementById('feed')){
db.collection('posts').orderBy('createdAt','desc')
.onSnapshot(snap=>{
feed.innerHTML='';
snap.forEach(doc=>{
const p=doc.data();
let imgs='';
(p.images||[]).forEach(u=>{imgs+=`<img src="${u}">`});
feed.innerHTML+=`
<div class="post">
<h3>${p.title}</h3>
<div class="tag" style="background:${p.tagColor}">${p.tag}</div>
${imgs}
<div class="desc truncate">${p.description}</div>
</div>`;
});
applyTruncation();
});
}

function savePost(){
const imgs=images.value.split('\n').filter(i=>i.trim());
db.collection('posts').add({
title:title.value,
tag:tag.value,
tagColor:tagColor.value,
description:description.value,
images:imgs,
createdAt:firebase.firestore.FieldValue.serverTimestamp()
}).then(()=>alert('Post published'));
}
