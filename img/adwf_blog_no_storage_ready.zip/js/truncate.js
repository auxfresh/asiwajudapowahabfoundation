function applyTruncation(){
document.querySelectorAll('.truncate').forEach(el=>{
const max=window.innerWidth<600?120:300;
if(el.innerText.length>max){
const full=el.innerText;
el.innerText=full.slice(0,max)+'... ';
const btn=document.createElement('span');
btn.innerText='Read more';
btn.style.color='blue';
btn.style.cursor='pointer';
btn.onclick=()=>{el.innerText=full};
el.appendChild(btn);
}
});
}